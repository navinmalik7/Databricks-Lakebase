# Databricks notebook source
# MAGIC %md
# MAGIC # 15 · Durable Gold build — overrides survive every rebuild (all tables)
# MAGIC For each write-back: a Silver view `<pg_table>_current` = the latest override per key (deletes drop out).
# MAGIC For each sync table with a `computed_source`: rebuild Gold as **override first, computed value second**
# MAGIC (`COALESCE`), as a MERGE so only changed rows create change-feed events for the synced tables.
# MAGIC
# MAGIC Use this as the Gold step of your normal pipeline instead of a plain "recompute everything".

# COMMAND ----------

# MAGIC %pip install -q -U "databricks-sdk>=0.89.0" "psycopg[binary,pool]>=3.1"

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %run ./00_config

# COMMAND ----------

if "CONFIG_LOADED" not in globals():
    raise RuntimeError("Config not loaded. Re-run the %run ./00_config cell (after the restartPython cell).")

# COMMAND ----------

syncs = load_sync_config()
wbs = load_writebacks()

# ---- 1. current-state view per write-back ----
for wb in wbs:
    if not USE_LAKEBASE_CDF:
        capture_changes(wb)
    keys = ", ".join(f"`{k}`" for k in wb["key_columns"])
    view = f"{CATALOG}.{SILVER}.{wb['pg_table']}_current"
    try:
        spark.table(wb["history"]).limit(0).collect()
    except Exception:
        wb["current_view"] = None
        print(f"- {wb['writeback_id']}: no history table yet ({wb['history']}) — its overrides are ignored in this build")
        continue
    wb["current_view"] = view
    spark.sql(f"""
      CREATE OR REPLACE VIEW {view} AS
      SELECT * EXCEPT (rn) FROM (
        SELECT *, ROW_NUMBER() OVER (PARTITION BY {keys} ORDER BY _sort_by DESC) AS rn
        FROM {wb['history']}
        WHERE _pg_change_type <> 'update_preimage')
      WHERE rn = 1 AND _pg_change_type <> 'delete'""")
    print(f"view {view}: {spark.table(view).count()} active override(s)")

# COMMAND ----------

# ---- 2. generated Gold build per table ----
def gold_build_sql(s):
    gold, comp = s["source_table"], fq(s["computed_source"])
    keys = s["primary_key"]
    gfields = table_fields(gold)
    cfields = table_fields(comp)
    mine = [wb for wb in wbs if wb["target_table"] == gold and wb.get("current_view")]
    joins, override_for, audit_by, audit_at = [], {}, [], []
    for i, wb in enumerate(mine):
        a = f"o{i}"
        joins.append(f"LEFT JOIN {wb['current_view']} {a} ON " +
                     " AND ".join(f"{a}.`{k}` = c.`{k}`" for k in wb["key_columns"]))
        for c in wb["columns"]:
            override_for[c["gold_column"]] = (a, c["pg_column"], c["merge_rule"])
        if wb["audit_by_column"]: audit_by.append((wb["audit_by_column"], f"{a}.updated_by"))
        if wb["audit_at_column"]: audit_at.append((wb["audit_at_column"], f"CAST({a}.updated_at AS TIMESTAMP)"))
    audit_exprs = {}
    for col_, e in audit_by + audit_at:                          # several write-backs → latest non-null wins
        audit_exprs.setdefault(col_, []).append(e)
    select = []
    for g, dt in gfields.items():
        t = dt.simpleString()
        if g in override_for:
            a, p, rule = override_for[g]
            base = f"c.`{g}`" if g in cfields else f"CAST(NULL AS {t})"
            expr = (f"COALESCE({a}.`{p}`, {base})" if rule == "COALESCE"
                    else f"CASE WHEN {a}.updated_by IS NOT NULL THEN {a}.`{p}` ELSE {base} END")
        elif g in audit_exprs:
            expr = f"COALESCE({', '.join(audit_exprs[g])})"
        elif g in cfields:
            expr = f"c.`{g}`"
        else:
            expr = f"CAST(NULL AS {t})"
        select.append(f"CAST({expr} AS {t}) AS `{g}`")
    on = " AND ".join(f"g.`{k}` = s.`{k}`" for k in keys)
    changed = " OR ".join(f"NOT (g.`{g}` <=> s.`{g}`)" for g in gfields if g not in keys)
    return f"""
MERGE INTO {gold} g
USING (SELECT {', '.join(select)}
       FROM {comp} c
       {' '.join(joins)}) s
ON {on}
WHEN MATCHED AND ({changed}) THEN UPDATE SET *
WHEN NOT MATCHED THEN INSERT *
WHEN NOT MATCHED BY SOURCE THEN DELETE"""

for s in syncs:
    if not s["computed_source"]:
        print(f"- {s['sync_id']:<16} no computed_source — skipped"); continue
    sql = gold_build_sql(s)
    m = spark.sql(sql).first()
    print(f"✔ {s['sync_id']:<16} rebuilt  "
          f"(updated {m.num_updated_rows}, inserted {m.num_inserted_rows}, deleted {m.num_deleted_rows})")

# COMMAND ----------

# MAGIC %md
# MAGIC ### See the generated SQL (for one table)

# COMMAND ----------

print(gold_build_sql(next(s for s in syncs if s["computed_source"])))

# COMMAND ----------

display(spark.sql(f"SELECT customer_id, segment, credit_limit, override_by FROM {CATALOG}.{GOLD}.customer_360 WHERE customer_id = 1042"))
display(spark.sql(f"SELECT product_id, list_price, is_active, override_by FROM {CATALOG}.{GOLD}.product_catalog WHERE product_id IN (7, 13)"))
display(spark.sql(f"SELECT store_id, sku, reorder_level, safety_stock, override_by FROM {CATALOG}.{GOLD}.store_inventory WHERE store_id = 3 AND sku = 21"))
