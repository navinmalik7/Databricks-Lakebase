# Databricks notebook source
# MAGIC %md
# MAGIC # 14 · Merge every write-back into its Gold table
# MAGIC For each enabled row in `config.writeback_tables` (in `apply_order`):
# MAGIC stream its history table → drop "before" images → keep the **latest change per key** → one MERGE that updates
# MAGIC **all configured columns together** (+ audit columns). Each table has its own checkpoint, so nothing is applied twice.
# MAGIC
# MAGIC The Gold change then fires that table's sync job from notebook 12 → Postgres `*_synced` follows → Power BI and the apps agree.
# MAGIC
# MAGIC Deleting an override row does not revert Gold here — that happens in the durable rebuild (notebook 15).

# COMMAND ----------

# MAGIC %pip install -q -U "databricks-sdk>=0.89.0" "psycopg[binary,pool]>=3.1"

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %run ./00_config

# COMMAND ----------

if "CONFIG_LOADED" not in globals():
    raise RuntimeError("Config not loaded. Re-run the %run ./00_config cell (after the restartPython cell).")

# COMMAND ----------

wbs = load_writebacks()

def build_set_clause(wb):
    sets = {}
    for c in wb["columns"]:
        g, p = c["gold_column"], c["pg_column"]
        sets[f"`{g}`"] = f"coalesce(o.`{p}`, g.`{g}`)" if c["merge_rule"] == "COALESCE" else f"o.`{p}`"
    if wb["audit_by_column"]: sets[f"`{ident(wb['audit_by_column'])}`"] = "o.updated_by"
    if wb["audit_at_column"]: sets[f"`{ident(wb['audit_at_column'])}`"] = "CAST(o.updated_at AS TIMESTAMP)"
    return sets

def make_batch_fn(target, keys, sets):
    on = " AND ".join(f"g.`{k}` = o.`{k}`" for k in keys)
    def apply_batch(batch_df, batch_id):
        # use the batch's own session (required on serverless / Spark Connect)
        from pyspark.sql import functions as F, Window
        from delta.tables import DeltaTable
        sp = batch_df.sparkSession
        latest = (batch_df.filter("_pg_change_type <> 'update_preimage'")
                  .withColumn("rn", F.row_number().over(Window.partitionBy(*keys).orderBy(F.col("_sort_by").desc())))
                  .filter("rn = 1"))
        (DeltaTable.forName(sp, target).alias("g")
            .merge(latest.alias("o"), on)
            .whenMatchedUpdate(condition="o._pg_change_type <> 'delete'", set=sets)
            .execute())
    return apply_batch

summary = []
for wb in wbs:
    if not USE_LAKEBASE_CDF:
        capture_changes(wb)                      # Option B: pick up new Postgres changes first
    try:
        spark.table(wb["history"]).limit(0).collect()
    except Exception:
        print(f"- {wb['writeback_id']:<20} no history table yet ({wb['history']}) — skipped"); continue
    sets = build_set_clause(wb)
    v_before = spark.sql(f"DESCRIBE HISTORY {wb['target_table']} LIMIT 1").first().version
    q = (spark.readStream.table(wb["history"])
           .writeStream.foreachBatch(make_batch_fn(wb["target_table"], wb["key_columns"], sets))
           .option("checkpointLocation", wb["checkpoint"])
           .trigger(availableNow=True)
           .start())
    q.awaitTermination()                           # one table at a time: no concurrent MERGEs into the same Gold table
    v_after = spark.sql(f"DESCRIBE HISTORY {wb['target_table']} LIMIT 1").first().version
    summary.append((wb["writeback_id"], wb["target_table"], ", ".join(c["gold_column"] for c in wb["columns"]),
                    int(v_after - v_before)))
    print(f"✔ {wb['writeback_id']:<20} → {wb['target_table']}  ({v_after - v_before} new Gold version(s))")

display(spark.createDataFrame(summary, "writeback string, gold_table string, columns string, gold_commits int"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Check: the demo rows in Gold

# COMMAND ----------

display(spark.sql(f"SELECT customer_id, segment, credit_limit, override_by, override_at FROM {CATALOG}.{GOLD}.customer_360 WHERE customer_id = 1042"))
display(spark.sql(f"SELECT product_id, list_price, is_active, override_by FROM {CATALOG}.{GOLD}.product_catalog WHERE product_id IN (7, 13)"))
display(spark.sql(f"SELECT store_id, sku, reorder_level, safety_stock, override_by FROM {CATALOG}.{GOLD}.store_inventory WHERE store_id = 3 AND sku = 21"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Schedule this notebook (once, off camera)
# MAGIC Option A: runs when **any** history table changes. Option B: every 5 minutes (capture + merge).

# COMMAND ----------

from databricks.sdk.service import jobs
nb_path = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()
name = "lakebase-writeback · merge all"
trigger = (jobs.TriggerSettings(
              table_update=jobs.TableUpdateTriggerConfiguration(
                  table_names=[wb["history"] for wb in wbs], condition=jobs.Condition.ANY_UPDATED,
                  min_time_between_triggers_seconds=60),
              pause_status=jobs.PauseStatus.UNPAUSED)
           if USE_LAKEBASE_CDF else
           jobs.TriggerSettings(
              periodic=jobs.PeriodicTriggerConfiguration(interval=5, unit=jobs.PeriodicTriggerConfigurationTimeUnit.MINUTES),
              pause_status=jobs.PauseStatus.UNPAUSED))
settings = dict(name=name, trigger=trigger, max_concurrent_runs=1,
                tasks=[jobs.Task(task_key="merge_writebacks", notebook_task=jobs.NotebookTask(notebook_path=nb_path))],
                tags={"framework": "lakebase-writeback"})
existing = next(iter(w.jobs.list(name=name)), None)
if existing:
    w.jobs.reset(job_id=existing.job_id, new_settings=jobs.JobSettings(**settings)); print("Job updated:", existing.job_id)
else:
    print("Job created:", w.jobs.create(**settings).job_id)
