# Databricks notebook source
# MAGIC %md
# MAGIC # 10 · Framework setup — config tables + demo Gold tables
# MAGIC Run once. Safe to re-run (everything is `IF NOT EXISTS` / MERGE).
# MAGIC
# MAGIC 1. Creates the three **config tables** in `retail.config`.
# MAGIC 2. Seeds them for three Gold tables: `customer_360` (from Part 2), `product_catalog`, `store_inventory` (composite key).
# MAGIC 3. Creates the two new demo Gold tables + their Silver "computed" sources if they don't exist.
# MAGIC
# MAGIC Prerequisite: `retail.gold.customer_360` from the original notebook `01_setup_freshcart`.

# COMMAND ----------

# MAGIC %pip install -q -U "databricks-sdk>=0.89.0" "psycopg[binary,pool]>=3.1"

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %run ./00_config

# COMMAND ----------

if "CONFIG_LOADED" not in globals():
    raise RuntimeError("Config not loaded. Re-run the %run ./00_config cell (after the restartPython cell).")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1 · Config tables

# COMMAND ----------

for s in (BRONZE, SILVER, GOLD, CONFIG):
    spark.sql(f"CREATE SCHEMA IF NOT EXISTS {CATALOG}.{s}")
spark.sql(f"CREATE VOLUME IF NOT EXISTS {CATALOG}.{BRONZE}.chk")

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {CFG_SYNC} (
  sync_id            STRING  NOT NULL COMMENT 'short unique name, e.g. customer_360',
  source_table       STRING  NOT NULL COMMENT 'Gold table (catalog.schema.table)',
  primary_key        ARRAY<STRING> NOT NULL COMMENT 'key column(s) of the Gold table',
  scheduling_policy  STRING  NOT NULL COMMENT 'SNAPSHOT | TRIGGERED | CONTINUOUS',
  synced_table       STRING  COMMENT 'UC name of the synced table; NULL = <source_table>_synced',
  timeseries_key     STRING  COMMENT 'optional: dedupe key when the source has duplicate PKs',
  computed_source    STRING  COMMENT 'optional: Silver table the Gold build reads (for notebook 15)',
  enabled            BOOLEAN NOT NULL,
  owner              STRING,
  comment            STRING,
  CONSTRAINT sync_tables_pk PRIMARY KEY (sync_id)
) COMMENT 'Which Gold tables are pushed to Lakebase Postgres'
""")

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {CFG_WB} (
  writeback_id     STRING  NOT NULL COMMENT 'short unique name, e.g. customer_overrides',
  pg_table         STRING  NOT NULL COMMENT 'table in Postgres schema app that the app writes to',
  target_table     STRING  NOT NULL COMMENT 'Gold table the changes are merged into',
  key_columns      ARRAY<STRING> NOT NULL COMMENT 'same names in Postgres and Gold',
  audit_by_column  STRING  COMMENT 'optional Gold column that receives updated_by',
  audit_at_column  STRING  COMMENT 'optional Gold column that receives updated_at',
  apply_order      INT     NOT NULL,
  enabled          BOOLEAN NOT NULL,
  owner            STRING,
  comment          STRING,
  CONSTRAINT writeback_tables_pk PRIMARY KEY (writeback_id)
) COMMENT 'Which Postgres tables flow back into Gold'
""")

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {CFG_WB_COLS} (
  writeback_id  STRING  NOT NULL,
  pg_column     STRING  NOT NULL COMMENT 'column in the Postgres write-back table',
  gold_column   STRING  NOT NULL COMMENT 'column it updates in the Gold table',
  merge_rule    STRING  NOT NULL COMMENT 'COALESCE (NULL = keep Gold value) | OVERWRITE (NULL clears it)',
  enabled       BOOLEAN NOT NULL,
  comment       STRING,
  CONSTRAINT writeback_columns_pk PRIMARY KEY (writeback_id, pg_column)
) COMMENT 'Which columns flow back, and into which Gold columns'
""")
print("Config tables ready:", CFG_SYNC, CFG_WB, CFG_WB_COLS)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2 · Demo Gold tables (`product_catalog`, `store_inventory`)
# MAGIC Same rules as `customer_360`: primary key, Change Data Feed on, audit columns ready for write-back.

# COMMAND ----------

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {CATALOG}.{SILVER}.product_computed AS
SELECT CAST(id AS BIGINT) AS product_id,
       concat('Product ', id) AS product_name,
       element_at(array('Fruit','Dairy','Bakery','Snacks','Beverages'), CAST(id % 5 AS INT) + 1) AS category,
       CAST(20 + (id * 7) % 480 AS DECIMAL(10,2)) AS list_price,
       true AS is_active
FROM range(1, 201)""")

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {CATALOG}.{GOLD}.product_catalog (
  product_id BIGINT NOT NULL, product_name STRING, category STRING,
  list_price DECIMAL(10,2), is_active BOOLEAN,
  override_by STRING, override_at TIMESTAMP,
  CONSTRAINT product_catalog_pk PRIMARY KEY (product_id))
TBLPROPERTIES (delta.enableChangeDataFeed = true)""")
spark.sql(f"""
MERGE INTO {CATALOG}.{GOLD}.product_catalog g USING {CATALOG}.{SILVER}.product_computed c
ON g.product_id = c.product_id
WHEN NOT MATCHED THEN INSERT (product_id, product_name, category, list_price, is_active)
  VALUES (c.product_id, c.product_name, c.category, c.list_price, c.is_active)""")

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {CATALOG}.{SILVER}.inventory_computed AS
SELECT CAST(s.id AS INT) AS store_id, CAST(p.id AS BIGINT) AS sku,
       CAST((s.id * 31 + p.id * 17) % 400 AS INT) AS on_hand,
       CAST(40 + (p.id % 6) * 10 AS INT) AS reorder_level,
       CAST(20 + (p.id % 4) * 5 AS INT)  AS safety_stock
FROM range(1, 6) s CROSS JOIN range(1, 51) p""")

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {CATALOG}.{GOLD}.store_inventory (
  store_id INT NOT NULL, sku BIGINT NOT NULL, on_hand INT,
  reorder_level INT, safety_stock INT,
  override_by STRING, override_at TIMESTAMP,
  CONSTRAINT store_inventory_pk PRIMARY KEY (store_id, sku))
TBLPROPERTIES (delta.enableChangeDataFeed = true)""")
spark.sql(f"""
MERGE INTO {CATALOG}.{GOLD}.store_inventory g USING {CATALOG}.{SILVER}.inventory_computed c
ON g.store_id = c.store_id AND g.sku = c.sku
WHEN NOT MATCHED THEN INSERT (store_id, sku, on_hand, reorder_level, safety_stock)
  VALUES (c.store_id, c.sku, c.on_hand, c.reorder_level, c.safety_stock)""")

for t in ("customer_360", "product_catalog", "store_inventory"):
    n = spark.table(f"{CATALOG}.{GOLD}.{t}").count()
    print(f"{CATALOG}.{GOLD}.{t}: {n} rows")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3 · Seed the config
# MAGIC This is the **only place you describe tables and columns**. To add a table later, add rows here
# MAGIC (or `INSERT` into the config tables) and re-run 11 → 12 → 13. See the README for a copy-paste example.

# COMMAND ----------

G = f"{CATALOG}.{GOLD}"; S = f"{CATALOG}.{SILVER}"

sync_rows = [
    # sync_id,          source_table,               primary_key,            policy,      synced_table, ts_key, computed_source,            enabled, owner,        comment
    ("customer_360",    f"{G}.customer_360",        ["customer_id"],        "TRIGGERED", None, None, f"{S}.customer_computed",  True, "data-team", "Support Portal lookups"),
    ("product_catalog", f"{G}.product_catalog",     ["product_id"],         "TRIGGERED", None, None, f"{S}.product_computed",   True, "data-team", "Pricing app"),
    ("store_inventory", f"{G}.store_inventory",     ["store_id", "sku"],    "TRIGGERED", None, None, f"{S}.inventory_computed", True, "data-team", "Store ops app"),
]
wb_rows = [
    # writeback_id,          pg_table,              target_table,          key_columns,        audit_by,      audit_at,     order, enabled, owner,        comment
    ("customer_overrides",  "customer_overrides",  f"{G}.customer_360",    ["customer_id"],    "override_by", "override_at", 10, True, "support-app", "Priya's credit-limit / segment edits"),
    ("product_overrides",   "product_overrides",   f"{G}.product_catalog", ["product_id"],     "override_by", "override_at", 20, True, "pricing-app", "price changes, de-listing"),
    ("inventory_overrides", "inventory_overrides", f"{G}.store_inventory", ["store_id", "sku"],"override_by", "override_at", 30, True, "store-ops",   "manual reorder thresholds"),
]
col_rows = [
    # writeback_id,          pg_column,       gold_column,     rule,       enabled, comment
    ("customer_overrides",  "credit_limit",  "credit_limit",  "COALESCE", True, None),
    ("customer_overrides",  "segment",       "segment",       "COALESCE", True, None),
    ("product_overrides",   "list_price",    "list_price",    "COALESCE", True, None),
    ("product_overrides",   "is_active",     "is_active",     "COALESCE", True, "false is a value, NULL means no change"),
    ("inventory_overrides", "reorder_level", "reorder_level", "COALESCE", True, None),
    ("inventory_overrides", "safety_stock",  "safety_stock",  "COALESCE", True, None),
]

def upsert(table, rows, keys):
    df = spark.createDataFrame(rows, spark.table(table).schema)
    df.createOrReplaceTempView("_seed")
    on = " AND ".join(f"t.{k} = s.{k}" for k in keys)
    spark.sql(f"MERGE INTO {table} t USING _seed s ON {on} "
              f"WHEN MATCHED THEN UPDATE SET * WHEN NOT MATCHED THEN INSERT *")

upsert(CFG_SYNC, sync_rows, ["sync_id"])
upsert(CFG_WB, wb_rows, ["writeback_id"])
upsert(CFG_WB_COLS, col_rows, ["writeback_id", "pg_column"])

display(spark.table(CFG_SYNC))
display(spark.table(CFG_WB))
display(spark.table(CFG_WB_COLS))
