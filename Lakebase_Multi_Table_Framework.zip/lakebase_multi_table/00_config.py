# Databricks notebook source
# MAGIC %md
# MAGIC # 00 · Config & helpers — Lakebase multi-table framework (FreshCart)
# MAGIC Every other notebook starts with `%run ./00_config`. Edit only the **settings** block at the top.
# MAGIC
# MAGIC **What's driven by config tables** (created by notebook `10_framework_setup`):
# MAGIC | Delta table | One row per … | Drives |
# MAGIC |---|---|---|
# MAGIC | `retail.config.sync_tables` | Gold table to push to Postgres | notebook 12 (synced tables + jobs) |
# MAGIC | `retail.config.writeback_tables` | Postgres table the apps write to | notebooks 13, 14, 15 |
# MAGIC | `retail.config.writeback_columns` | editable column (Postgres column → Gold column) | notebooks 13, 14, 15 |

# COMMAND ----------

# =============================== settings ===============================
CATALOG = "retail"
BRONZE, SILVER, GOLD, CONFIG = "bronze", "silver", "gold", "config"

PROJECT_ID    = "freshcart"       # Lakebase project id
PG_DATABASE   = "freshcart_app"   # Postgres database the synced tables land in
PG_APP_SCHEMA = "app"             # schema the apps own — the ONLY schema the change feed watches

# How Postgres changes reach the lakehouse:
#   True  → Lakebase Change Data Feed (Public Preview; needs a catalog on YOUR cloud storage, not Default Storage)
#   False → the notebook captures changes itself (works everywhere, incl. Free Edition)
USE_LAKEBASE_CDF = False
CDF_CATALOG, CDF_SCHEMA = CATALOG, BRONZE      # where Lakebase CDF writes (must be on external storage if True)

# ============================ derived names =============================
CFG_SYNC    = f"{CATALOG}.{CONFIG}.sync_tables"
CFG_WB      = f"{CATALOG}.{CONFIG}.writeback_tables"
CFG_WB_COLS = f"{CATALOG}.{CONFIG}.writeback_columns"
HIST_CATALOG, HIST_SCHEMA = (CDF_CATALOG, CDF_SCHEMA) if USE_LAKEBASE_CDF else (CATALOG, BRONZE)
CHK_ROOT = f"/Volumes/{CATALOG}/{BRONZE}/chk/" + ("cdf" if USE_LAKEBASE_CDF else "nb")
AUDIT_PG_COLS = ["reason", "updated_by", "updated_at"]   # every write-back table gets these

import re, time, sys, subprocess, importlib, json
try:
    import psycopg
except ModuleNotFoundError:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "-q", "psycopg[binary,pool]>=3.1"])
    importlib.invalidate_caches(); import psycopg

from databricks.sdk import WorkspaceClient
w = WorkspaceClient()
if not hasattr(w, "postgres"):
    raise RuntimeError('databricks-sdk too old. First cell: %pip install -U "databricks-sdk>=0.89.0" "psycopg[binary,pool]>=3.1"')
ME = w.current_user.me().user_name

# ---------------------------- Lakebase helpers ----------------------------
def project_name(): return f"projects/{PROJECT_ID}"

def branch_name():
    b = w.postgres.get_project(name=project_name()).status.default_branch
    return b if b.startswith("projects/") else f"{project_name()}/branches/{b}"

def rw_endpoint():
    eps = list(w.postgres.list_endpoints(parent=branch_name()))
    for ep in eps:
        if ep.status and ep.status.endpoint_type and ep.status.endpoint_type.name.endswith("READ_WRITE"):
            return ep
    return eps[0]

def pg_connect(database=None):
    ep = rw_endpoint()
    cred = w.postgres.generate_database_credential(endpoint=ep.name)      # OAuth token, ≤ 1 h — never print it
    return psycopg.connect(host=ep.status.hosts.host, dbname=database or PG_DATABASE, user=ME,
                           password=cred.token, sslmode="require", autocommit=True)

def pg(sql, params=None, database=None, fetch=True):
    with pg_connect(database) as conn:
        cur = conn.execute(sql, params)
        return cur.fetchall() if (fetch and cur.description) else None

def database_resource(pg_db=None):
    pg_db = pg_db or PG_DATABASE
    for d in w.postgres.list_databases(parent=branch_name()):
        if d.status and d.status.postgres_database == pg_db:
            return d.name
    raise ValueError(f"Postgres database {pg_db} not found — run notebook 12 first (the first synced table creates it).")

# ------------------------------ name safety ------------------------------
_IDENT = re.compile(r"^[a-z_][a-z0-9_]*$")
def ident(name):
    """Allow only simple lower-case identifiers in generated SQL (config values are not trusted blindly)."""
    if not isinstance(name, str) or not _IDENT.match(name):
        raise ValueError(f"Invalid identifier in config: {name!r} (use lower_snake_case)")
    return name

def fq(name):
    """Validate catalog.schema.table."""
    parts = name.split(".")
    if len(parts) != 3: raise ValueError(f"Expected catalog.schema.table, got {name!r}")
    return ".".join(ident(p) for p in parts)

# ------------------------------ type mapping ------------------------------
def spark_type_to_pg(dt):
    s = dt.simpleString()
    m = re.match(r"decimal\((\d+),(\d+)\)", s)
    if m: return f"NUMERIC({m.group(1)},{m.group(2)})"
    table = {"bigint": "BIGINT", "int": "INTEGER", "smallint": "SMALLINT", "tinyint": "SMALLINT",
             "string": "TEXT", "boolean": "BOOLEAN", "double": "DOUBLE PRECISION", "float": "REAL",
             "date": "DATE", "timestamp": "TIMESTAMPTZ", "timestamp_ntz": "TIMESTAMP"}
    if s in table: return table[s]
    raise ValueError(f"Type {s} is not supported for write-back columns")

def table_fields(table):
    return {f.name: f.dataType for f in spark.table(table).schema.fields}

# ------------------------------ config loaders ------------------------------
def history_table(pg_table):
    """Bronze history table for one Postgres write-back table (Lakebase CDF naming: lb_<table>_history)."""
    return f"{HIST_CATALOG}.{HIST_SCHEMA}.lb_{ident(pg_table)}_history"

def load_sync_config():
    rows = spark.table(CFG_SYNC).where("enabled").orderBy("sync_id").collect()
    out = []
    for r in rows:
        d = r.asDict()
        d["source_table"] = fq(d["source_table"])
        d["synced_table"] = fq(d["synced_table"] or d["source_table"] + "_synced")
        d["primary_key"] = [ident(k) for k in d["primary_key"]]
        out.append(d)
    return out

def load_writebacks():
    wbs = spark.table(CFG_WB).where("enabled").orderBy("apply_order", "writeback_id").collect()
    cols = spark.table(CFG_WB_COLS).where("enabled").collect()
    out = []
    for r in wbs:
        d = r.asDict()
        d["pg_table"] = ident(d["pg_table"])
        d["target_table"] = fq(d["target_table"])
        d["key_columns"] = [ident(k) for k in d["key_columns"]]
        d["columns"] = [{"pg_column": ident(c.pg_column), "gold_column": ident(c.gold_column),
                         "merge_rule": (c.merge_rule or "COALESCE").upper()}
                        for c in cols if c.writeback_id == r.writeback_id]
        d["history"] = history_table(d["pg_table"])
        d["checkpoint"] = f"{CHK_ROOT}/wb_{ident(d['writeback_id'])}"
        out.append(d)
    return out

def history_ddl(wb):
    """Spark DDL of the history table for one write-back (same columns Lakebase CDF writes)."""
    gf = table_fields(wb["target_table"])
    cols = [f"`{k}` {gf[k].simpleString()}" for k in wb["key_columns"]]
    cols += [f"`{c['pg_column']}` {gf[c['gold_column']].simpleString()}" for c in wb["columns"]]
    cols += ["reason string", "updated_by string", "updated_at timestamp"]
    meta = ["_pg_change_type string", "_pg_lsn bigint", "_pg_xid int", "_timestamp timestamp", "_sort_by bigint"]
    return ", ".join(cols), ", ".join(cols + meta)

# ------------------- Option B: capture changes from a notebook -------------------
def capture_changes(wb):
    """Diff the Postgres write-back table against the latest state in its history table and append
    insert / update_postimage / delete rows — the same shape Lakebase CDF writes. Returns rows appended."""
    from pyspark.sql import functions as F, Window
    keys = wb["key_columns"]
    vals = [c["pg_column"] for c in wb["columns"]] + AUDIT_PG_COLS
    src_ddl, hist_ddl = history_ddl(wb)
    spark.sql(f"CREATE TABLE IF NOT EXISTS {wb['history']} ({hist_ddl})")
    sel = ", ".join(f'"{c}"' for c in keys + vals)
    rows = pg(f'SELECT {sel} FROM "{PG_APP_SCHEMA}"."{wb["pg_table"]}"') or []
    src = spark.createDataFrame(rows, src_ddl)
    cur = (spark.table(wb["history"]).where("_pg_change_type <> 'update_preimage'")
           .withColumn("rn", F.row_number().over(Window.partitionBy(*keys).orderBy(F.col("_sort_by").desc())))
           .where("rn = 1 AND _pg_change_type <> 'delete'").select(*keys, *vals))
    j = src.alias("s").join(cur.alias("c"), keys, "full_outer")
    same = " AND ".join(f"s.`{c}` <=> c.`{c}`" for c in vals)
    out = (j.select(*keys,
                    *[F.coalesce(F.col(f"s.`{c}`"), F.col(f"c.`{c}`")).alias(c) for c in vals],
                    F.when(F.col("c.updated_by").isNull(), "insert")
                     .when(F.col("s.updated_by").isNull(), "delete")
                     .when(F.expr(same), None).otherwise("update_postimage").alias("_pg_change_type"))
             .where("_pg_change_type IS NOT NULL"))
    base = int(time.time() * 1_000_000) * 1000
    out = (out.withColumn("_pg_lsn", F.lit(None).cast("bigint")).withColumn("_pg_xid", F.lit(None).cast("int"))
              .withColumn("_timestamp", F.current_timestamp())
              .withColumn("_sort_by", F.lit(base) + F.row_number().over(Window.orderBy(*keys))))
    n = out.count()
    if n: out.write.mode("append").saveAsTable(wb["history"])
    print(f"  captured {n:>3} change(s)  {PG_APP_SCHEMA}.{wb['pg_table']} → {wb['history']}")
    return n

CONFIG_LOADED = True
print(f"Config loaded ✔  user: {ME} | catalog: {CATALOG} | project: {PROJECT_ID} | db: {PG_DATABASE} | "
      f"change capture: {'Lakebase CDF' if USE_LAKEBASE_CDF else 'notebook (Option B)'}")
