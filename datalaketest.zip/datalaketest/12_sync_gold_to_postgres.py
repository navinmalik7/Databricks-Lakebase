# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "6"
# ///
# MAGIC %md
# MAGIC # 12 · Gold → Postgres for every table in `config.sync_tables`
# MAGIC For each enabled row:
# MAGIC 1. switch on Change Data Feed on the Gold table (Triggered / Continuous need it),
# MAGIC 2. create the **synced table** if it doesn't exist (`<schema>.<table>_synced` in Postgres),
# MAGIC 3. wait until all of them are online,
# MAGIC 4. create / update **one job per table** that re-syncs when *that* Gold table changes.
# MAGIC
# MAGIC Re-running is safe: existing synced tables and jobs are left alone or updated, never duplicated.

# COMMAND ----------

# MAGIC %pip install -q -U "databricks-sdk>=0.89.0" "psycopg[binary,pool]>=3.1"

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %run ./00_config

# COMMAND ----------

if "CONFIG_LOADED" not in globals():
    raise RuntimeError("Config not loaded. Re-run the %run ./00_config cell (after the restartPython cell).")

# COMMAND ----------

for p in w.postgres.list_projects():
    print(p.name, "|", p.status.display_name if p.status else "")

# COMMAND ----------

# from databricks.sdk.service.postgres import Project, ProjectSpec, Endpoint, EndpointSpec, EndpointType
# from databricks.sdk.common.types.fieldmask import FieldMask

# try:
#     proj = w.postgres.get_project(name=project_name())
#     print("Project exists:", proj.name)
# except Exception:
#     print(f"Creating project '{PROJECT_ID}' … (1–2 min)")
#     proj = w.postgres.create_project(
#         project=Project(spec=ProjectSpec(pg_version=17, display_name="FreshCart")),
#         project_id=PROJECT_ID).wait()
#     ep = rw_endpoint()
#     w.postgres.update_endpoint(                      # compute autoscales 2–8 CU, as in the video
#         name=ep.name,
#         endpoint=Endpoint(name=ep.name, spec=EndpointSpec(
#             endpoint_type=EndpointType.ENDPOINT_TYPE_READ_WRITE,
#             autoscaling_limit_min_cu=2.0, autoscaling_limit_max_cu=8.0)),
#         update_mask=FieldMask(field_mask=["spec.autoscaling_limit_min_cu",
#                                           "spec.autoscaling_limit_max_cu"])).wait()
#     print("✔ Created:", proj.name)

# print("Branch:", branch_name())

# COMMAND ----------

from databricks.sdk.service.postgres import (
    SyncedTable, SyncedTableSyncedTableSpec,
    SyncedTableSyncedTableSpecSyncedTableSchedulingPolicy as Policy,
)
from databricks.sdk.service import jobs

syncs = load_sync_config()
print(f"{len(syncs)} table(s) to sync:", [s["sync_id"] for s in syncs])
BRANCH = branch_name()

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1 · Change Data Feed + synced tables

# COMMAND ----------

def get_synced(name):
    try: return w.postgres.get_synced_table(name=f"synced_tables/{name}")
    except Exception: return None

created = []
for s in syncs:
    if s["scheduling_policy"] != "SNAPSHOT":
        spark.sql(f"ALTER TABLE {s['source_table']} SET TBLPROPERTIES (delta.enableChangeDataFeed = true)")
    if get_synced(s["synced_table"]):
        print(f"= {s['sync_id']:<16} synced table exists: {s['synced_table']}")
        continue
    spec = SyncedTableSyncedTableSpec(
        source_table_full_name=s["source_table"],
        branch=BRANCH,
        primary_key_columns=s["primary_key"],
        scheduling_policy=Policy[s["scheduling_policy"]],
        postgres_database=PG_DATABASE,
        create_database_objects_if_missing=True,
        timeseries_key=s["timeseries_key"],
    )
    # start all creates first, wait afterwards — tables provision in parallel
    op = w.postgres.create_synced_table(synced_table=SyncedTable(spec=spec), synced_table_id=s["synced_table"])
    created.append((s, op))
    print(f"+ {s['sync_id']:<16} creating {s['synced_table']} …")

for s, op in created:
    op.wait()
    print(f"✔ {s['sync_id']:<16} created")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2 · Wait until every synced table is online
# MAGIC The first load copies the whole table, so big tables take longer.

# COMMAND ----------

def state_of(name):
    st = get_synced(name).status
    return (st.detailed_state.name if st and st.detailed_state else "UNKNOWN"), st

pending = {s["sync_id"]: s for s in syncs}
t0 = time.time()
while pending and time.time() - t0 < 1800:
    for sid, s in list(pending.items()):
        state, st = state_of(s["synced_table"])
        if "FAILED" in state:
            raise RuntimeError(f"{sid}: {state} — {st.message}")
        if state.startswith("SYNCED_TABLE_ONLINE") and "UPDATING" not in state and "TRIGGERED_UPDATE" not in state:
            print(f"✔ {sid:<16} {state}  last sync {st.last_sync_time}")
            pending.pop(sid)
    if pending:
        print(f"… {int(time.time()-t0)}s waiting for {list(pending)}"); time.sleep(20)
if pending:
    raise RuntimeError(f"Timed out waiting for {list(pending)}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3 · One job per table, triggered by *that* table's updates
# MAGIC One job per table keeps it precise: a change to `product_catalog` re-syncs only `product_catalog`.
# MAGIC SNAPSHOT tables get a daily schedule instead; CONTINUOUS tables need no job.

# COMMAND ----------

def job_by_name(name):
    for j in w.jobs.list(name=name):
        return j
    return None

for s in syncs:
    if s["scheduling_policy"] == "CONTINUOUS":
        print(f"- {s['sync_id']:<16} CONTINUOUS — no job needed"); continue
    pipeline_id = state_of(s["synced_table"])[1].pipeline_id
    name = f"lakebase-sync · {s['sync_id']}"
    settings = dict(
        name=name,
        tasks=[jobs.Task(task_key=f"sync_{s['sync_id']}", pipeline_task=jobs.PipelineTask(pipeline_id=pipeline_id))],
        tags={"framework": "lakebase-sync", "sync_id": s["sync_id"]},
    )
    if s["scheduling_policy"] == "TRIGGERED":
        settings["trigger"] = jobs.TriggerSettings(
            table_update=jobs.TableUpdateTriggerConfiguration(table_names=[s["source_table"]],
                                                              min_time_between_triggers_seconds=60),
            pause_status=jobs.PauseStatus.UNPAUSED)
    else:   # SNAPSHOT
        settings["schedule"] = jobs.CronSchedule(quartz_cron_expression="0 0 2 * * ?", timezone_id="Asia/Kolkata",
                                                 pause_status=jobs.PauseStatus.UNPAUSED)
    existing = job_by_name(name)
    if existing:
        w.jobs.reset(job_id=existing.job_id, new_settings=jobs.JobSettings(**settings))
        print(f"↻ {s['sync_id']:<16} job updated  {w.config.host}/jobs/{existing.job_id}")
    else:
        j = w.jobs.create(**settings)
        print(f"+ {s['sync_id']:<16} job created  {w.config.host}/jobs/{j.job_id}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4 · Check from the Postgres side

# COMMAND ----------

for s in syncs:
    uc_schema, uc_table = s["synced_table"].split(".")[1:]
    n = pg(f'SELECT count(*) FROM "{uc_schema}"."{uc_table}"')[0][0]
    print(f"{s['sync_id']:<16} Postgres {uc_schema}.{uc_table}: {n} rows")