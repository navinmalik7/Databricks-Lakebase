# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "6"
# ///
# MAGIC %md
# MAGIC # 13 · Postgres write-back tables + change capture, from `config.writeback_*`
# MAGIC For each enabled write-back:
# MAGIC 1. create `app.<pg_table>` in Postgres — key columns + every configured column (types copied from Gold)
# MAGIC    + `reason`, `updated_by`, `updated_at`. Columns added to the config later are added with `ADD COLUMN IF NOT EXISTS`.
# MAGIC 2. `REPLICA IDENTITY FULL` (full before/after rows for the change feed).
# MAGIC 3. **Option A** — one Lakebase CDF feed on schema `app` covers *all* write-back tables.
# MAGIC    **Option B** — the notebook captures changes (`capture_changes`) into history tables of the same shape.
# MAGIC
# MAGIC The apps write **only** to `app.*` tables. The synced tables (`gold.*_synced`) stay read-only.

# COMMAND ----------

# MAGIC %pip install -q -U "databricks-sdk>=0.89.0" "psycopg[binary,pool]>=3.1"

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %run ./00_config

# COMMAND ----------

if "CONFIG_LOADED" not in globals():
    raise RuntimeError("Config not loaded. Re-run the %run ./00_config cell (after the restartPython cell).")

# COMMAND ----------

wbs = load_writebacks()
print(f"{len(wbs)} write-back table(s):", [wb["writeback_id"] for wb in wbs])

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1 · Create / evolve the Postgres tables

# COMMAND ----------

def pg_columns(pg_table):
    rows = pg("SELECT column_name FROM information_schema.columns WHERE table_schema = %s AND table_name = %s",
              (PG_APP_SCHEMA, pg_table)) or []
    return {r[0] for r in rows}

pg(f'CREATE SCHEMA IF NOT EXISTS "{ident(PG_APP_SCHEMA)}"', fetch=False)

for wb in wbs:
    gf = table_fields(wb["target_table"])
    keys = wb["key_columns"]
    key_defs = [f'"{k}" {spark_type_to_pg(gf[k])} NOT NULL' for k in keys]
    col_defs = [f'"{c["pg_column"]}" {spark_type_to_pg(gf[c["gold_column"]])}' for c in wb["columns"]]
    audit = ['"reason" TEXT', '"updated_by" TEXT NOT NULL', '"updated_at" TIMESTAMPTZ NOT NULL DEFAULT now()']
    pk = ", ".join(f'"{k}"' for k in keys)
    tbl = f'"{PG_APP_SCHEMA}"."{wb["pg_table"]}"'

    existing = pg_columns(wb["pg_table"])
    if not existing:
        pg(f"CREATE TABLE {tbl} ({', '.join(key_defs + col_defs + audit)}, PRIMARY KEY ({pk}))", fetch=False)
        print(f"+ {tbl} created")
    else:
        added = []
        for c, d in zip([c["pg_column"] for c in wb["columns"]], col_defs):
            if c not in existing:
                pg(f"ALTER TABLE {tbl} ADD COLUMN IF NOT EXISTS {d}", fetch=False); added.append(c)
        print(f"= {tbl} exists" + (f" — added columns {added}" if added else ""))
    pg(f"ALTER TABLE {tbl} REPLICA IDENTITY FULL", fetch=False)

display(spark.createDataFrame(
    [(wb["pg_table"], r[0], r[1]) for wb in wbs for r in pg(
        "SELECT column_name, data_type FROM information_schema.columns WHERE table_schema=%s AND table_name=%s ORDER BY ordinal_position",
        (PG_APP_SCHEMA, wb["pg_table"]))],
    "pg_table string, column string, type string"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2 · The upsert each app runs (generated from config)
# MAGIC Shown for the app teams. A column the user didn't touch is sent as NULL — with `COALESCE` rules that means "no change".

# COMMAND ----------

for wb in wbs:
    keys = wb["key_columns"]; cols = [c["pg_column"] for c in wb["columns"]]
    allc = keys + cols + ["reason", "updated_by"]
    sets = ", ".join(f'"{c}" = EXCLUDED."{c}"' for c in cols + ["reason", "updated_by"]) + ', "updated_at" = now()'
    print(f"-- {wb['writeback_id']}\n"
          f'INSERT INTO "{PG_APP_SCHEMA}"."{wb["pg_table"]}" ({", ".join(chr(34)+c+chr(34) for c in allc)})\n'
          f'VALUES ({", ".join(["%s"]*len(allc))})\n'
          f'ON CONFLICT ({", ".join(chr(34)+k+chr(34) for k in keys)}) DO UPDATE SET {sets};\n')

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3 · Demo: three apps change several columns at once
# MAGIC Priya (credit limit **and** segment), the pricing app (price **and** de-list), store ops (two thresholds on a composite key).

# COMMAND ----------

names = {wb['pg_table'] for wb in wbs}
if 'customer_overrides' in names:
    pg(f'''INSERT INTO "{PG_APP_SCHEMA}".customer_overrides (customer_id, credit_limit, segment, reason, updated_by)
           VALUES (1042, 75000, 'Platinum', 'Loyal, 3 yrs on-time payments', 'priya@freshcart.in')
           ON CONFLICT (customer_id) DO UPDATE SET credit_limit = EXCLUDED.credit_limit, segment = EXCLUDED.segment,
             reason = EXCLUDED.reason, updated_by = EXCLUDED.updated_by, updated_at = now()''', fetch=False)
if 'product_overrides' in names:
    pg(f'''INSERT INTO "{PG_APP_SCHEMA}".product_overrides (product_id, list_price, is_active, reason, updated_by)
           VALUES (7, 59.00, NULL, 'Diwali promo', 'pricing-bot'), (13, NULL, false, 'Supplier recall', 'arjun@freshcart.in')
           ON CONFLICT (product_id) DO UPDATE SET list_price = EXCLUDED.list_price, is_active = EXCLUDED.is_active,
             reason = EXCLUDED.reason, updated_by = EXCLUDED.updated_by, updated_at = now()''', fetch=False)
if 'inventory_overrides' in names:
    pg(f'''INSERT INTO "{PG_APP_SCHEMA}".inventory_overrides (store_id, sku, reorder_level, safety_stock, reason, updated_by)
           VALUES (3, 21, 120, 60, 'Festival demand', 'meera@freshcart.in')
           ON CONFLICT (store_id, sku) DO UPDATE SET reorder_level = EXCLUDED.reorder_level, safety_stock = EXCLUDED.safety_stock,
             reason = EXCLUDED.reason, updated_by = EXCLUDED.updated_by, updated_at = now()''', fetch=False)
for wb in wbs:
    print(wb["pg_table"], pg(f'SELECT * FROM "{PG_APP_SCHEMA}"."{wb["pg_table"]}"'))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4 · Change capture
# MAGIC **Option A (`USE_LAKEBASE_CDF = True`)** — one feed on schema `app` → a `lb_<table>_history` Delta table per write-back table.
# MAGIC In the UI: Lakebase app → branch → **Lakebase CDF** → Start → schema `app` → catalog/schema from `CDF_CATALOG`/`CDF_SCHEMA`.
# MAGIC A table only appears once it has at least one row. If you add a new write-back table later, check `wal2delta.tables`;
# MAGIC if it isn't listed, stop and start the feed.
# MAGIC
# MAGIC **Option B (`USE_LAKEBASE_CDF = False`)** — `capture_changes()` per table (notebook 14 also calls it before every merge).

# COMMAND ----------

if USE_LAKEBASE_CDF:
    from databricks.sdk.service.postgres import CdfConfig
    db_res = database_resource()
    feeds = [c for c in w.postgres.list_cdf_configs(parent=db_res) if c.postgres_schema == PG_APP_SCHEMA]
    if feeds:
        print("Feed already running:", feeds[0].name)
    else:
        op = w.postgres.create_cdf_config(parent=db_res, cdf_config=CdfConfig(
            catalog=CDF_CATALOG, schema=CDF_SCHEMA, postgres_schema=PG_APP_SCHEMA))
        print("Feed started:", op.wait().name)
    for _ in range(20):
        rows = pg("SELECT * FROM wal2delta.tables"); print(rows)
        if rows and len(rows) >= len(wbs) and all("STREAMING" in str(r) for r in rows): break
        time.sleep(15)
else:
    for wb in wbs:
        capture_changes(wb)

# COMMAND ----------

for wb in wbs:
    print(wb["history"])
    display(spark.table(wb["history"]).orderBy("_sort_by", ascending=False).limit(5))