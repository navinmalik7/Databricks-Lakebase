# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "6"
# ///
# MAGIC %md
# MAGIC # 11 · Validate the config
# MAGIC Run after every config change, **before** 12 / 13. Prints one row per check: `OK`, `WARN` or `ERROR`.
# MAGIC Any `ERROR` stops the notebook (so a scheduled job fails loudly instead of syncing the wrong thing).

# COMMAND ----------

# MAGIC %pip install -q -U "databricks-sdk>=0.89.0" "psycopg[binary,pool]>=3.1"

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %run ./00_config

# COMMAND ----------

if "CONFIG_LOADED" not in globals():
    raise RuntimeError("Config not loaded. Re-run the %run ./00_config cell (after the restartPython cell).")

# COMMAND ----------

results = []
def chk(level, scope, msg): results.append((level, scope, msg))

def table_exists(t):
    try: spark.table(t).limit(0).collect(); return True
    except Exception: return False

# ---------------- sync_tables ----------------
try:
    syncs = load_sync_config()
except Exception as e:
    syncs = []; chk("ERROR", "sync_tables", f"cannot load: {e}")

synced_uc_schemas, seen_synced = set(), set()
for s in syncs:
    sc = f"sync:{s['sync_id']}"
    src = s["source_table"]
    if s["scheduling_policy"] not in ("SNAPSHOT", "TRIGGERED", "CONTINUOUS"):
        chk("ERROR", sc, f"scheduling_policy must be SNAPSHOT/TRIGGERED/CONTINUOUS, got {s['scheduling_policy']}")
    if not table_exists(src):
        chk("ERROR", sc, f"source table {src} not found"); continue
    fields = table_fields(src)
    missing = [k for k in s["primary_key"] if k not in fields]
    if missing:
        chk("ERROR", sc, f"primary key column(s) {missing} not in {src}"); continue
    if s["timeseries_key"] and s["timeseries_key"] not in fields:
        chk("ERROR", sc, f"timeseries_key {s['timeseries_key']} not in {src}")
    keys = ", ".join(f"`{k}`" for k in s["primary_key"])
    nulls = spark.sql(f"SELECT count(*) c FROM {src} WHERE " + " OR ".join(f"`{k}` IS NULL" for k in s["primary_key"])).first().c
    if nulls: chk("WARN", sc, f"{nulls} row(s) with NULL key — the sync skips them")
    dups = spark.sql(f"SELECT count(*) c FROM (SELECT {keys} FROM {src} GROUP BY {keys} HAVING count(*) > 1)").first().c
    if dups and not s["timeseries_key"]:
        chk("ERROR", sc, f"{dups} duplicate key(s) — the sync fails; dedupe or set timeseries_key")
    props = {r.key: r.value for r in spark.sql(f"SHOW TBLPROPERTIES {src}").collect()}
    if s["scheduling_policy"] != "SNAPSHOT" and props.get("delta.enableChangeDataFeed", "false").lower() != "true":
        chk("WARN", sc, "Change Data Feed is off — notebook 12 will switch it on")
    if s["synced_table"] in seen_synced:
        chk("ERROR", sc, f"synced_table {s['synced_table']} used twice")
    seen_synced.add(s["synced_table"])
    synced_uc_schemas.add(s["synced_table"].split(".")[1])     # becomes the Postgres schema name
    if s["computed_source"] and not table_exists(fq(s["computed_source"])):
        chk("WARN", sc, f"computed_source {s['computed_source']} not found — notebook 15 will skip this table")
    chk("OK", sc, f"{src} → {s['synced_table']} ({s['scheduling_policy']}, key {s['primary_key']})")

# loop guard: the write-back schema must never be a synced-table schema
if PG_APP_SCHEMA in synced_uc_schemas:
    chk("ERROR", "global", f"PG_APP_SCHEMA '{PG_APP_SCHEMA}' is also a synced-table schema — the change feed would loop")

# ---------------- writeback_tables / columns ----------------
try:
    wbs = load_writebacks()
except Exception as e:
    wbs = []; chk("ERROR", "writeback_tables", f"cannot load: {e}")

sync_keys = {s["source_table"]: s["primary_key"] for s in syncs}
claimed, seen_pg = {}, set()
for wb in wbs:
    sc = f"writeback:{wb['writeback_id']}"
    tgt = wb["target_table"]
    if wb["pg_table"] in seen_pg: chk("ERROR", sc, f"pg_table {wb['pg_table']} used twice")
    seen_pg.add(wb["pg_table"])
    if not table_exists(tgt):
        chk("ERROR", sc, f"target table {tgt} not found"); continue
    fields = table_fields(tgt)
    for k in wb["key_columns"]:
        if k not in fields: chk("ERROR", sc, f"key column {k} not in {tgt}")
    if tgt in sync_keys and sorted(sync_keys[tgt]) != sorted(wb["key_columns"]):
        chk("WARN", sc, f"key_columns {wb['key_columns']} differ from the sync primary key {sync_keys[tgt]}")
    if not wb["columns"]:
        chk("ERROR", sc, "no enabled rows in writeback_columns"); continue
    for c in wb["columns"]:
        g = c["gold_column"]
        if g not in fields: chk("ERROR", sc, f"gold_column {g} not in {tgt}"); continue
        if g in wb["key_columns"]: chk("ERROR", sc, f"{g} is a key column — keys can't be edited")
        if c["pg_column"] in wb["key_columns"] + AUDIT_PG_COLS:
            chk("ERROR", sc, f"pg_column {c['pg_column']} clashes with a key/audit column name")
        if c["merge_rule"] not in ("COALESCE", "OVERWRITE"):
            chk("ERROR", sc, f"merge_rule for {g} must be COALESCE or OVERWRITE")
        try: spark_type_to_pg(fields[g])
        except ValueError as e: chk("ERROR", sc, str(e))
        owner = claimed.get((tgt, g))
        if owner and owner != wb["writeback_id"]:
            chk("ERROR", sc, f"{tgt}.{g} is already written by {owner} — one owner per Gold column")
        claimed[(tgt, g)] = wb["writeback_id"]
    for a in (wb["audit_by_column"], wb["audit_at_column"]):
        if a and a not in fields: chk("ERROR", sc, f"audit column {a} not in {tgt}")
    chk("OK", sc, f"{PG_APP_SCHEMA}.{wb['pg_table']} → {tgt}  columns {[c['gold_column'] for c in wb['columns']]}")

# COMMAND ----------

res = spark.createDataFrame(results, "level string, scope string, message string")
display(res.orderBy("level", "scope"))
errors = [r for r in results if r[0] == "ERROR"]
print(f"{len(results)} checks · {len(errors)} error(s) · {sum(1 for r in results if r[0]=='WARN')} warning(s)")
if errors:
    raise RuntimeError("Config has errors — fix them before running 12/13:\n" + "\n".join(f"  {s}: {m}" for _, s, m in errors))