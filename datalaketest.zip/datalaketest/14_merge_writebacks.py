# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "6"
# ///
# MAGIC %md
# MAGIC # 14 · Merge every write-back into its Gold table
# MAGIC For each enabled row in `config.writeback_tables` (in `apply_order`):
# MAGIC stream its history table → drop "before" images → keep the **latest change per key** → one MERGE that updates
# MAGIC **all configured columns together** (+ audit columns). Each table has its own checkpoint, so nothing is applied twice.
# MAGIC
# MAGIC The Gold change then fires that table's sync job from notebook 12 → Postgres `*_synced` follows → Power BI and the apps agree.
# MAGIC
# MAGIC Deleting an override row does not revert Gold here — that happens in the durable rebuild (notebook 15).

# COMMAND ----------

# MAGIC %pip install -q -U "databricks-sdk>=0.89.0" "psycopg[binary,pool]>=3.1"

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %run ./00_config

# COMMAND ----------

if "CONFIG_LOADED" not in globals():
    raise RuntimeError("Config not loaded. Re-run the %run ./00_config cell (after the restartPython cell).")

# COMMAND ----------

wbs = load_writebacks()

# Progress per write-back: the highest _sort_by already merged (replaces streaming checkpoints).
STATE = f"{CATALOG}.{CONFIG}.writeback_state"
spark.sql(f"""CREATE TABLE IF NOT EXISTS {STATE} (
  writeback_id STRING NOT NULL, last_sort_by BIGINT, rows_merged BIGINT, updated_at TIMESTAMP)
  COMMENT 'How far each write-back history table has been merged into Gold'""")

def last_sort_by(wb_id):
    r = spark.sql(f"SELECT last_sort_by FROM {STATE} WHERE writeback_id = '{ident(wb_id)}'").first()
    return r.last_sort_by if r and r.last_sort_by is not None else -1

def merge_sql(wb, lo, hi):
    """Latest change per key with lo < _sort_by <= hi, merged into Gold — all configured columns at once."""
    keys = wb["key_columns"]
    sets = []
    for c in wb["columns"]:
        g_, p_ = c["gold_column"], c["pg_column"]
        sets.append(f"g.`{g_}` = " + (f"coalesce(o.`{p_}`, g.`{g_}`)" if c["merge_rule"] == "COALESCE" else f"o.`{p_}`"))
    if wb["audit_by_column"]: sets.append(f"g.`{ident(wb['audit_by_column'])}` = o.updated_by")
    if wb["audit_at_column"]: sets.append(f"g.`{ident(wb['audit_at_column'])}` = CAST(o.updated_at AS TIMESTAMP)")
    part = ", ".join(f"`{k}`" for k in keys)
    on = " AND ".join(f"g.`{k}` = o.`{k}`" for k in keys)
    return f"""
MERGE INTO {wb['target_table']} g
USING (
  SELECT * EXCEPT (rn) FROM (
    SELECT *, ROW_NUMBER() OVER (PARTITION BY {part} ORDER BY _sort_by DESC) AS rn
    FROM {wb['history']}
    WHERE _pg_change_type <> 'update_preimage' AND _sort_by > {int(lo)} AND _sort_by <= {int(hi)})
  WHERE rn = 1) o
ON {on}
WHEN MATCHED AND o._pg_change_type <> 'delete' THEN UPDATE SET {', '.join(sets)}"""

summary = []
for wb in wbs:
    if not USE_LAKEBASE_CDF:
        capture_changes(wb)                      # Option B: pick up new Postgres changes first
    try:
        spark.table(wb["history"]).limit(0).collect()
    except Exception:
        print(f"- {wb['writeback_id']:<20} no history table yet ({wb['history']}) — skipped"); continue
    lo = last_sort_by(wb["writeback_id"])
    hi = spark.sql(f"SELECT max(_sort_by) m FROM {wb['history']}").first().m
    if hi is None or hi <= lo:
        print(f"= {wb['writeback_id']:<20} nothing new"); summary.append((wb["writeback_id"], wb["target_table"], 0, 0)); continue
    m = spark.sql(merge_sql(wb, lo, hi)).first()
    updated = int(m.num_updated_rows or 0)
    # record progress only after the MERGE succeeded (re-running the same range is harmless: same values)
    spark.sql(f"""MERGE INTO {STATE} s USING (SELECT '{ident(wb["writeback_id"])}' AS writeback_id) n
                  ON s.writeback_id = n.writeback_id
                  WHEN MATCHED THEN UPDATE SET last_sort_by = {int(hi)}, rows_merged = coalesce(s.rows_merged, 0) + {updated},
                                               updated_at = current_timestamp()
                  WHEN NOT MATCHED THEN INSERT (writeback_id, last_sort_by, rows_merged, updated_at)
                                        VALUES (n.writeback_id, {int(hi)}, {updated}, current_timestamp())""")
    summary.append((wb["writeback_id"], wb["target_table"], updated, 1))
    print(f"✔ {wb['writeback_id']:<20} → {wb['target_table']}  {updated} Gold row(s) updated")

display(spark.createDataFrame(summary, "writeback string, gold_table string, rows_updated long, merges int"))
display(spark.table(STATE))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Check: the demo rows in Gold

# COMMAND ----------

display(spark.sql(f"SELECT customer_id, segment, credit_limit, override_by, override_at FROM {CATALOG}.{GOLD}.customer_360 WHERE customer_id = 1042"))
display(spark.sql(f"SELECT product_id, list_price, is_active, override_by FROM {CATALOG}.{GOLD}.product_catalog WHERE product_id IN (7, 13)"))
display(spark.sql(f"SELECT store_id, sku, reorder_level, safety_stock, override_by FROM {CATALOG}.{GOLD}.store_inventory WHERE store_id = 3 AND sku = 21"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Schedule this notebook (once, off camera)
# MAGIC Option A: runs when **any** history table changes. Option B: every 5 minutes (capture + merge).

# COMMAND ----------

from databricks.sdk.service import jobs
nb_path = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()
name = "lakebase-writeback · merge all"
trigger = (jobs.TriggerSettings(
              table_update=jobs.TableUpdateTriggerConfiguration(
                  table_names=[wb["history"] for wb in wbs], condition=jobs.Condition.ANY_UPDATED,
                  min_time_between_triggers_seconds=60),
              pause_status=jobs.PauseStatus.UNPAUSED)
           if USE_LAKEBASE_CDF else
           jobs.TriggerSettings(
              periodic=jobs.PeriodicTriggerConfiguration(interval=5, unit=jobs.PeriodicTriggerConfigurationTimeUnit.MINUTES),
              pause_status=jobs.PauseStatus.UNPAUSED))
settings = dict(name=name, trigger=trigger, max_concurrent_runs=1,
                tasks=[jobs.Task(task_key="merge_writebacks", notebook_task=jobs.NotebookTask(notebook_path=nb_path))],
                tags={"framework": "lakebase-writeback"})
existing = next(iter(w.jobs.list(name=name)), None)
if existing:
    w.jobs.reset(job_id=existing.job_id, new_settings=jobs.JobSettings(**settings)); print("Job updated:", existing.job_id)
else:
    print("Job created:", w.jobs.create(**settings).job_id)